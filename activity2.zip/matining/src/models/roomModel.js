const mongoose = require('mongoose');

const roomSchema =new mongoose .Schema({
    roomNumber: {
        type: Number,
        require: true,
        unique: true,
    },
    type: {
        type: String,
        require: true,
         
    },
    price:{
        type:Number,
        unique: true,

    },
    isBooked: {
        type: Boolean,
        default: false,
    },
    features: [String],
});

module.exports = mongoose.model('Room', roomSchema);
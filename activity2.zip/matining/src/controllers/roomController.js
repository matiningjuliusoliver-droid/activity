const rooms = require('../roomModel');
const Room = require('../models/roomModel');

const getAllRooms = async (req, res) =>{
    try {
        const rooms = await Room.find();
        res.status(200).json(rooms);     
    } catch (error){
        res.status(500).json({ message: error.message});
    }
};


const createRoom = async (req,res) => {
    try {
        const newRoom = await Room.create (req.body);
        res.status(201).json(newRoom);
    } catch (error) {
        res.status(400).json({message: error.message });
    }
};


const  getRoomById = async (req,res) => {
    try {
        const room = await Room.findById (req.params.id);
        if (!rooms) return res.status(404).son({ message: 'Room not found'});
        res.status(200).json(room);
    } catch (error) {
        res.status(500).json({message: error.message });
    }
};

const updateRoom = async (req,res) => {
    try {
        const room = await Room.findByIdAndUpdate(req.params.id, req.body, {
            new: true
        });
        if (!room) return res.status(404).json({message: 'Room not found'});
    } catch (error) {
        res.status(400).json({message: error.message});
    }
};



const  deleteRoom = async (req,res) => {
    try {
        const room = await Room.findByIdAndDelete (req.params.id);
        if (!rooms) return res.status(404).son({ message: 'Room not found'});
        res.status(200).json({message: 'Room deleted succesfully' });
    } catch (error) {
        res.status(500).json({message: error.message });
    }
};

module.exports ={
    getAllRooms,
    createRoom,
    updateRoom,
    getRoomById,
    deleteRoom,
};